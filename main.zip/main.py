import tkinter as tk
from tkinter import messagebox
import json
import os

TASKS_FILE = "tasks.json"

class ToDoApp:
    def __init__(self, root):
        self.root = root
        self.root.title("To-Do List App")
        self.root.geometry("600x500")  # Start in normal window
        self.root.minsize(400, 400)    # Minimum size allowed

        # Fullscreen toggle
        self.root.bind("<F11>", self.toggle_fullscreen)
        self.root.bind("<Escape>", self.exit_fullscreen)
        self.fullscreen = False

        # Header Label
        header = tk.Label(root, text="To-Do List", font=("Segoe UI", 16, "bold"))
        header.pack(pady=(10, 5))

        self.tasks = []

        # Entry field
        self.entry = tk.Entry(root, font=("Segoe UI", 12))
        self.entry.pack(padx=10, pady=(20, 10), fill=tk.X)

        # Add Task Button
        self.add_button = tk.Button(root, text="Add Task", font=("Segoe UI", 11), command=self.add_task)
        self.add_button.pack(pady=(0, 10))

        # Task Listbox
        self.listbox = tk.Listbox(root, font=("Segoe UI", 12), selectmode=tk.SINGLE)
        self.listbox.pack(padx=10, pady=10, expand=True, fill=tk.BOTH)

        # Action Buttons
        btn_frame = tk.Frame(root)
        btn_frame.pack(pady=10)

        self.delete_button = tk.Button(btn_frame, text="Delete", font=("Segoe UI", 11), width=10, command=self.delete_task)
        self.delete_button.pack(side=tk.LEFT, padx=5)

        self.mark_done_button = tk.Button(btn_frame, text="Mark as Done", font=("Segoe UI", 11), width=12, command=self.mark_done)
        self.mark_done_button.pack(side=tk.LEFT, padx=5)

        # Load existing tasks
        self.load_tasks()

    def add_task(self):
        task = self.entry.get().strip()
        if not task:
            messagebox.showwarning("Warning", "Please enter a task.")
            return

        self.tasks.append({"text": task, "completed": False})
        self.entry.delete(0, tk.END)
        self.save_tasks()
        self.refresh_listbox()

    def delete_task(self):
        selected = self.listbox.curselection()
        if not selected:
            messagebox.showinfo("Info", "Select a task to delete.")
            return

        index = selected[0]
        del self.tasks[index]
        self.save_tasks()
        self.refresh_listbox()

    def mark_done(self):
        selected = self.listbox.curselection()
        if not selected:
            messagebox.showinfo("Info", "Select a task to mark as done.")
            return

        index = selected[0]
        self.tasks[index]["completed"] = True
        self.save_tasks()
        self.refresh_listbox()

    def refresh_listbox(self):
        self.listbox.delete(0, tk.END)
        for task in self.tasks:
            display = f"✔ {task['text']}" if task["completed"] else task["text"]
            self.listbox.insert(tk.END, display)

    def save_tasks(self):
        with open(TASKS_FILE, "w") as f:
            json.dump(self.tasks, f)

    def load_tasks(self):
        if os.path.exists(TASKS_FILE):
            with open(TASKS_FILE, "r") as f:
                self.tasks = json.load(f)
        self.refresh_listbox()

    def toggle_fullscreen(self, event=None):
        self.fullscreen = not self.fullscreen
        self.root.attributes("-fullscreen", self.fullscreen)

    def exit_fullscreen(self, event=None):
        self.fullscreen = False
        self.root.attributes("-fullscreen", False)

if __name__ == "__main__":
    root = tk.Tk()
    app = ToDoApp(root)
    root.mainloop()
