import tkinter as tk
from tkinter import ttk, messagebox
from tkcalendar import Calendar
from datetime import datetime

TASKS_FILE = "todo_tasks.txt"

class ToDoApp:
    def __init__(self, root):
        self.root = root
        self.root.title("My To-Do List")
        self.root.geometry("600x700")
        self.root.minsize(500, 600)

        self.tasks = []
        self.theme = "light"

        self.setup_styles()
        self.build_ui()
        self.load_tasks()
        self.display_tasks()

    def setup_styles(self):
        self.style = ttk.Style()
        self.style.theme_use("clam")
        self.update_theme()

    def update_theme(self):
        if self.theme == "light":
            bg = "#f9f9f9"
            fg = "#333333"
            accent = "#007acc"
            entry_bg = "#ffffff"
        else:
            bg = "#1f1f1f"
            fg = "#eeeeee"
            accent = "#00b7ff"
            entry_bg = "#2c2c2c"

        self.root.configure(bg=bg)
        self.style.configure("TFrame", background=bg)
        self.style.configure("TLabel", background=bg, foreground=fg, font=("Segoe UI", 11))
        self.style.configure("Header.TLabel", font=("Segoe UI", 22, "bold"), foreground=accent, background=bg)
        self.style.configure("Accent.TButton", font=("Segoe UI", 11, "bold"), background=accent, foreground="white", padding=8)
        self.style.map("Accent.TButton",
                       background=[("active", "#005f99"), ("pressed", "#004d80")],
                       foreground=[("active", "white")])
        self.style.configure("TEntry", fieldbackground=entry_bg, foreground=fg)

    def build_ui(self):
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(2, weight=1)

        top_frame = ttk.Frame(self.root, padding=(10, 10))
        top_frame.grid(row=0, column=0, sticky="ew")
        top_frame.columnconfigure(1, weight=1)

        menu_btn = ttk.Menubutton(top_frame, text="≡", width=3)
        menu = tk.Menu(menu_btn, tearoff=0)
        menu.add_command(label="Select All", command=self.select_all)
        menu.add_command(label="Delete Completed", command=self.delete_completed)
        menu.add_separator()
        menu.add_command(label="Toggle Theme", command=self.toggle_theme)
        menu_btn["menu"] = menu
        menu_btn.grid(row=0, column=0, sticky="w")

        self.header_label = ttk.Label(top_frame, text="MY TO-DO LIST", style="Header.TLabel")
        self.header_label.grid(row=0, column=1, sticky="nsew")

        task_frame = ttk.Frame(self.root, padding=(10, 5))
        task_frame.grid(row=2, column=0, sticky="nsew")
        task_frame.columnconfigure(0, weight=1)
        task_frame.rowconfigure(0, weight=1)

        self.text = tk.Text(task_frame, font=("Segoe UI", 12), wrap="word", bg="white", fg="#333", relief="flat",
                            padx=12, pady=10, bd=2, height=20)
        self.text.grid(row=0, column=0, sticky="nsew")
        self.text.config(state="disabled")

        scrollbar = tk.Scrollbar(task_frame, orient="vertical", command=self.text.yview)
        self.text.config(yscrollcommand=scrollbar.set)
        scrollbar.place(x=10000, y=0)

        self.text.bind("<MouseWheel>", lambda e: self.text.yview_scroll(-1 * int(e.delta / 120), "units"))
        self.text.bind("<Button-1>", self.on_text_click)

        self.add_task_btn = ttk.Button(self.root, text="+", width=3, command=self.open_add_task_popup,
                                       style="Accent.TButton")
        self.add_task_btn.place(relx=0.95, rely=0.93, anchor="se")

    def open_add_task_popup(self):
        popup = tk.Toplevel(self.root)
        popup.title("Add Task")
        popup.resizable(False, False)

        popup_width = 400
        popup_height = 420
        x = self.root.winfo_x() + (self.root.winfo_width() // 2) - (popup_width // 2)
        y = self.root.winfo_y() + (self.root.winfo_height() // 2) - (popup_height // 2)
        popup.geometry(f"{popup_width}x{popup_height}+{x}+{y}")
        popup.transient(self.root)
        popup.grab_set()
        popup.configure(bg=self.root["bg"])

        frame = ttk.Frame(popup, padding=10)
        frame.pack(fill="both", expand=True)

        ttk.Label(frame, text="Task:").grid(row=0, column=0, sticky="w")
        task_entry = ttk.Entry(frame, font=("Segoe UI", 11))
        task_entry.grid(row=0, column=1, sticky="ew", pady=5)
        frame.columnconfigure(1, weight=1)

        ttk.Label(frame, text="Deadline Date:").grid(row=1, column=0, sticky="w")

        # Calendar always visible
        calendar = Calendar(frame, selectmode="day", date_pattern="dd-mm-yyyy", font=("Segoe UI", 10))
        calendar.grid(row=2, column=0, columnspan=2, pady=5)

        # Time Picker
        ttk.Label(frame, text="Time (12hr):").grid(row=3, column=0, sticky="w")

        now = datetime.now()
        hour_str = tk.StringVar(value=now.strftime("%I"))
        minute_str = tk.StringVar(value=now.strftime("%M"))
        ampm_str = tk.StringVar(value=now.strftime("%p"))

        time_frame = ttk.Frame(frame)
        time_frame.grid(row=3, column=1, sticky="w", pady=5)

        hour_box = ttk.Combobox(time_frame, textvariable=hour_str, values=[f"{h:02}" for h in range(1, 13)], width=3, state="readonly")
        minute_box = ttk.Combobox(time_frame, textvariable=minute_str, values=[f"{m:02}" for m in range(0, 60)], width=3, state="readonly")
        ampm_box = ttk.Combobox(time_frame, textvariable=ampm_str, values=["AM", "PM"], width=3, state="readonly")

        hour_box.pack(side="left", padx=2)
        minute_box.pack(side="left", padx=2)
        ampm_box.pack(side="left", padx=2)

        def submit_task():
            task_text = task_entry.get().strip()
            if not task_text:
                messagebox.showwarning("Missing Task", "Please enter a task description.")
                return

            date_str = calendar.get_date()
            try:
                deadline = datetime.strptime(date_str, "%d-%m-%Y").strftime("%d-%m-%Y")
            except ValueError:
                messagebox.showerror("Invalid Date", "Please select a valid date.")
                return

            hour = hour_str.get()
            minute = minute_str.get()
            ampm = ampm_str.get()

            if hour and minute and ampm:
                deadline += f" {hour}:{minute} {ampm}"

            self.tasks.append({"text": task_text, "deadline": deadline, "completed": False})
            self.save_tasks()
            self.display_tasks()
            popup.destroy()

        button_frame = ttk.Frame(frame)
        button_frame.grid(row=4, column=0, columnspan=2, pady=10)
        ttk.Button(button_frame, text="Add", command=submit_task, style="Accent.TButton").pack(side="left", padx=5)
        ttk.Button(button_frame, text="Cancel", command=popup.destroy).pack(side="left", padx=5)

        task_entry.focus()

    def display_tasks(self):
        self.text.config(state="normal")
        self.text.delete(1.0, tk.END)

        self.tasks.sort(key=lambda t: t["completed"])

        for task in self.tasks:
            mark = "[✓]" if task["completed"] else "[ ]"
            deadline = task["deadline"] or "N/A"
            line = f"{mark} {task['text']} (Due: {deadline})\n"
            self.text.insert(tk.END, line)

        self.text.config(state="disabled")

    def on_text_click(self, event):
        index = self.text.index(f"@{event.x},{event.y}")
        line_num = int(index.split('.')[0]) - 1
        if 0 <= line_num < len(self.tasks):
            self.tasks[line_num]["completed"] = not self.tasks[line_num]["completed"]
            self.save_tasks()
            self.display_tasks()

    def select_all(self):
        for task in self.tasks:
            task["completed"] = True
        self.save_tasks()
        self.display_tasks()

    def delete_completed(self):
        self.tasks = [t for t in self.tasks if not t["completed"]]
        self.save_tasks()
        self.display_tasks()

    def toggle_theme(self):
        self.theme = "dark" if self.theme == "light" else "light"
        self.update_theme()
        self.display_tasks()

    def save_tasks(self):
        try:
            with open(TASKS_FILE, "w") as f:
                f.write(str(self.tasks))
        except:
            pass

    def load_tasks(self):
        try:
            with open(TASKS_FILE, "r") as f:
                self.tasks = eval(f.read())
        except:
            self.tasks = []

if __name__ == "__main__":
    root = tk.Tk()
    app = ToDoApp(root)
    root.mainloop()
